this is a Wordle game here u have to geuss word correctly
you will get some clues
if after entering first word letter is replaced by "." then that letter is there in selected word but not correct place and if same letter is reprinted the that given letter is there in selected word and that is on its correct place
here you get totel 6 attempts